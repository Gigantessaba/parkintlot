import React from 'react';
import ParkingList from './components/ParkingList';

const App = () => {
    return (
        <div>
            <ParkingList />
        </div>
    );
};

export default App;
